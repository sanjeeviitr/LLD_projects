package org.example.BookMyShow;

public class User {

    private String name;
    private String userId;
    private String phoneNo;
    private String email;

    public User(String name, String userId, String phoneNo, String email) {
        this.name = name;
        this.userId = userId;
        this.phoneNo = phoneNo;
        this.email = email;
    }



}
