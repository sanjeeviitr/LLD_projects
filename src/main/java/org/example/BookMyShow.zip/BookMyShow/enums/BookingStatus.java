package org.example.BookMyShow.enums;

public enum BookingStatus {

    CREATED,
    PAYMENT_PENDING,
    CONFIRMED,
    CANCELLED,
    EXPIRED
}
