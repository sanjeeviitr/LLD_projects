package org.example.BookMyShow.enums;

public enum PaymentStatus {

    INPROGRESS,
    SUCCESS,
    FAILED,
    REFUNDED
}
