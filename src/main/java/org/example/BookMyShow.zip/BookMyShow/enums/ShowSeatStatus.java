package org.example.BookMyShow.enums;

public enum ShowSeatStatus {

    AVAILABLE,
    LOCKED,
    BOOKED
}
