package org.example.BookMyShow.enums;

public enum SeatType {

    SILVER,
    GOLD,
    PLATINUM
}
