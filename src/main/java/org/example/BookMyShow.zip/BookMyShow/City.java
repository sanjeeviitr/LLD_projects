package org.example.BookMyShow;

public class City {

    private String cityName;
    private String cityId;

    public City(String name, String id){
        this.cityId = id;
        this.cityName = name;
    }
}
